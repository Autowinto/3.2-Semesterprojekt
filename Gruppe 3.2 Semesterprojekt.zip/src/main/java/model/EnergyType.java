package worldofzuul.model;

public enum EnergyType {
    WIND,
    SOLAR,
    WATER
}
